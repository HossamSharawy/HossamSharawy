function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6KnsDBXXEFW":
        Script1();
        break;
      case "6bvzK9y6zP0":
        Script2();
        break;
      case "6NXDy8hIaKb":
        Script3();
        break;
      case "6aVxZsXwbl9":
        Script4();
        break;
      case "6k4RDb72xHC":
        Script5();
        break;
      case "5sPqjNJVQy0":
        Script6();
        break;
      case "6WnqEdx8QL9":
        Script7();
        break;
      case "6G0GssSITVJ":
        Script8();
        break;
      case "5hZqjXNn3I5":
        Script9();
        break;
      case "5iXAzve8gZG":
        Script10();
        break;
      case "5n8huC3ZIJ2":
        Script11();
        break;
      case "5uY7y7ES9zM":
        Script12();
        break;
      case "6UpFmksGtD0":
        Script13();
        break;
      case "6FOLecSRkl7":
        Script14();
        break;
      case "5aODDfiwhaP":
        Script15();
        break;
      case "5lDk9ymbUxK":
        Script16();
        break;
      case "69B2y65a4Ey":
        Script17();
        break;
      case "6mrHbiSsDsc":
        Script18();
        break;
      case "6gaUQknRALA":
        Script19();
        break;
      case "6mdK3mBMcav":
        Script20();
        break;
      case "5l3bqjQ8wYP":
        Script21();
        break;
      case "5yEzjWsGbqo":
        Script22();
        break;
      case "5VurvuiPORb":
        Script23();
        break;
      case "6QXwQW8NOoh":
        Script24();
        break;
      case "6QJZhppgEnZ":
        Script25();
        break;
      case "5l9ZQctVPve":
        Script26();
        break;
      case "5wMeMMK9NyG":
        Script27();
        break;
      case "6gwKpgThiRQ":
        Script28();
        break;
      case "6Yp2POObMH1":
        Script29();
        break;
      case "5XvfebGGcKV":
        Script30();
        break;
      case "6obQCLuBDVm":
        Script31();
        break;
      case "6kKN3aGO4GZ":
        Script32();
        break;
      case "5m37pIYto2R":
        Script33();
        break;
      case "66ADho4B8aR":
        Script34();
        break;
      case "6IBYA2eLJXB":
        Script35();
        break;
  }
}

function Script1()
{
  $('button.btn-reset').hide();

}

function Script2()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script3()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script4()
{
  $('button.btn-reset').hide();

}

function Script5()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script6()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script7()
{
  $('button.btn-reset').hide();

}

function Script8()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script9()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script10()
{
  $('button.btn-reset').hide();

}

function Script11()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script12()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script13()
{
  $('button.btn-reset').hide();

}

function Script14()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script15()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script16()
{
  $('button.btn-reset').hide();

}

function Script17()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script18()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script19()
{
  $('button.btn-reset').hide();

}

function Script20()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script21()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script22()
{
  $('button.btn-reset').hide();

}

function Script23()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script24()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script25()
{
  $('button.btn-reset').hide();

}

function Script26()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script27()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script28()
{
  $('button.btn-reset').hide();

}

function Script29()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script30()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script31()
{
  $('button.btn-reset').hide();

}

function Script32()
{
      var player= GetPlayer();
  var audioIsMuted= player.GetVar("audioIsMuted");
  Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = audioIsMuted;
});
}

function Script33()
{
  var player= GetPlayer();
  //console.log(player);
  var audioIsMuted= player.GetVar("audioIsMuted");
  console.log("audioIsMuted: " , audioIsMuted);

Array.prototype.slice.call(document.querySelectorAll('audio')).forEach(function(audio) {
    audio.muted = !audioIsMuted;
});

if(audioIsMuted) {
  player.SetVar("audioIsMuted", false); 
 console.log("audioIsMuted: " , audioIsMuted);
}
else {
player.SetVar("audioIsMuted", true);
 console.log("audioIsMuted: " , audioIsMuted);

}
}

function Script34()
{
  $('button.btn-reset').hide();

}

function Script35()
{
  $('button.btn-reset').hide();

}

